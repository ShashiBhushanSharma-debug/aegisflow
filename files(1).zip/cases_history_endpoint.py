# ─────────────────────────────────────────────────────────────────────
# ADD THIS TO backend/api/v1/endpoints/cases.py
#
# CRITICAL: place it ABOVE the @router.get("/{case_id}") route.
# FastAPI matches routes in order — if /{case_id} comes first it will
# swallow "/history" as a case id and return 404.
# ─────────────────────────────────────────────────────────────────────

# Everything that has left the review queue, newest first.
HISTORY_STATUSES = [
    "DRAFTED", "SUBMITTED", "CONCEDED", "WON", "LOST",
    "CLOSED", "REJECTED", "BLOCKED", "SUBMIT_FAILED", "FAILED",
]


@router.get("/history")
async def case_history(limit: int = 50):
    r = (supabase.table("cases")
         .select("*, claims(*), policy_decisions(*)")
         .in_("status", HISTORY_STATUSES)
         .order("updated_at", desc=True)
         .limit(limit).execute())
    return {"cases": r.data}


@router.get("/stats")
async def case_stats():
    rows = supabase.table("cases").select("status, amount").execute().data or []

    contested = {"SUBMITTED", "WON"}
    conceded = {"CONCEDED", "LOST"}

    def total(statuses):
        return sum(float(x.get("amount") or 0) for x in rows if x["status"] in statuses)

    return {
        "total_cases": len(rows),
        "awaiting_review": sum(1 for x in rows if x["status"] == "HUMAN_REVIEW"),
        "contested": sum(1 for x in rows if x["status"] in contested),
        "conceded": sum(1 for x in rows if x["status"] in conceded),
        "amount_contested": round(total(contested), 2),
        "amount_conceded": round(total(conceded), 2),
    }
